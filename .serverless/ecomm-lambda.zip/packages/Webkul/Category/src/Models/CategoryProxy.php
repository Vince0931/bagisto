<?php

namespace Webkul\Category\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CategoryProxy extends ModelProxy
{

}