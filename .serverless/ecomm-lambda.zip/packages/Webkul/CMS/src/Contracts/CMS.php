<?php

namespace Webkul\CMS\Contracts;

interface CMS
{
}