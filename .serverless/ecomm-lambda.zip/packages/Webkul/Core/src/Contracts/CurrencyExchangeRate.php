<?php

namespace Webkul\Core\Contracts;

interface CurrencyExchangeRate
{
}