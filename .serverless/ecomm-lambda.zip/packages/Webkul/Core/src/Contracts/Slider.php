<?php

namespace Webkul\Core\Contracts;

interface Slider
{
}