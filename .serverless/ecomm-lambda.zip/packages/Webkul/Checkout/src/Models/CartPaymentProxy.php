<?php

namespace Webkul\Checkout\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartPaymentProxy extends ModelProxy
{

}