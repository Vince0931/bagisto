<?php

namespace Webkul\Checkout\Contracts;

interface CartItem
{
}